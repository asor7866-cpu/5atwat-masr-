# 🚀 دليل سريع لتطبيق Migrations

## الطريقة الموصى بها (من Dashboard)

### الخطوة 1: افتح لوحة التحكم
1. اذهب إلى: https://supabase.com/dashboard
2. سجّل دخول بحساب `asor`
3. اختر مشروع: `wsmibothncghcpacwrag`

### الخطوة 2: افتح SQL Editor
```
Dashboard → SQL Editor → New Query
```

### الخطوة 3: شغّل الملف الأول
1. افتح الملف: `supabase/migrations/001_create_tables.sql`
2. انسخ **كل المحتوى**
3. الصقه في SQL Editor
4. اضغط **Run** (أو Ctrl/Cmd + Enter)
5. انتظر حتى يظهر "Success!"

### الخطوة 4: شغّل الملف الثاني
1. افتح الملف: `supabase/migrations/002_row_level_security.sql`
2. انسخ **كل المحتوى**
3. الصقه في SQL Editor (استبدل القديم)
4. اضغط **Run**
5. انتظر "Success!"

### الخطوة 5: شغّل الملف الثالث
1. افتح الملف: `supabase/migrations/003_storage_buckets.sql`
2. انسخ **كل المحتوى**
3. الصقه في SQL Editor
4. اضغط **Run**
5. انتظر "Success!"

---

## ✅ التحقق من النجاح

### 1. تحقق من الجداول
```
Dashboard → Table Editor
```
يجب أن ترى:
- users
- artifacts
- quizzes
- news
- favorites
- وغيرها...

### 2. تحقق من Storage
```
Dashboard → Storage
```
يجب أن ترى:
- artifacts
- models-3d
- audio-guides
- avatars
- news
- quizzes

### 3. تحقق من Auth
```
Dashboard → Authentication → Providers
```
تأكد من تفعيل:
- Email
- Google (اختياري)

---

## 🔧 إعدادات إضافية

### تفعيل Email Authentication
1. اذهب إلى: **Authentication → Providers**
2. فعّل **Email**
3. اختر:
   - ✅ Enable Email Confirmations (موصى به)
   - ✅ Enable Email Change Confirmations

### إعداد Google OAuth (اختياري)
1. في **Authentication → Providers**
2. فعّل **Google**
3. ستحتاج:
   - Google Client ID
   - Google Client Secret
   - من [Google Cloud Console](https://console.cloud.google.com)

---

## ❓ استكشاف الأخطاء

### خطأ: "permission denied for schema public"
**الحل**: تأكد من أنك مسجل دخول كـ Owner للمشروع

### خطأ: "relation already exists"
**الحل**: الجداول موجودة مسبقاً - هذا طبيعي إذا كنت تعيد التشغيل

### خطأ: "syntax error"
**الحل**: تأكد من نسخ **كل** محتوى الملف بدون تعديل

---

## 🎉 انتهيت؟

بعد تطبيق الـ migrations بنجاح:

1. **اختبر المصادقة**:
   ```
   قم بتسجيل حساب جديد من التطبيق
   ```

2. **أضف بيانات تجريبية** (اختياري):
   ```sql
   -- في SQL Editor
   INSERT INTO public.artifacts (
     name, name_en, description, description_en,
     era, category, current_location, is_featured
   ) VALUES (
     'قناع توت عنخ آمون',
     'Tutankhamun Mask',
     'القناع الذهبي الشهير',
     'The famous golden mask',
     'new_kingdom',
     'jewelry',
     'المتحف المصري الكبير',
     true
   );
   ```

3. **شغّل التطبيق**:
   ```bash
   npm run android
   # أو
   npm run ios
   ```

---

## 📞 هل تحتاج مساعدة؟

- راجع [SUPABASE_SETUP.md](../SUPABASE_SETUP.md) للتفاصيل الكاملة
- راجع [supabase/README.md](README.md) لفهم هيكل قاعدة البيانات
