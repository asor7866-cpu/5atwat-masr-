# 🏛️ 5atwat Masr - خطوات مصر

<div align="center">

![5atwat Masr Logo](./src/assets/icon.png)

**اكتشف أسرار مصر القديمة مع خطوات مصر**

[![React Native](https://img.shields.io/badge/React%20Native-0.73-blue.svg)](https://reactnative.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.3-blue.svg)](https://www.typescriptlang.org/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

</div>

---

## 📱 عن التطبيق

تطبيق **5atwat Masr** هو دليلك الذكي لاستكشاف كنوز الحضارة المصرية القديمة. يقدم التطبيق تجربة تفاعلية غنية تجمع بين التكنولوجيا الحديثة والتراث العريق.

---

## ✨ المميزات الرئيسية

### 🏺 استكشاف الآثار
- عرض آثار مصر القديمة (تماثيل، توابيت، معابد، أدوات)
- تصنيف حسب العصور والأماكن
- صور عالية الجودة ومجسمات 3D

### 🤖 المرشد الذكي (AI Guide)
- دردشة ذكية للإجابة على الأسئلة
- التعرف على الآثار بالكاميرا
- شرح صوتي بالعربية والإنجليزية

### 🎧 الدليل الصوتي
- شرح صوتي احترافي لكل قطعة
- دعم اللغتين العربية والإنجليزية
- إمكانية التحكم في السرعة

### 🗺️ خريطة تفاعلية
- خريطة المتحف بالطوابق
- تحديد موقع كل قطعة
- اقتراح مسارات الزيارة

### 🎮 ألعاب تعليمية
- اختبارات معرفية
- توصيل وترتيب
- نظام نقاط وإنجازات

### 📰 أخبار واكتشافات
- آخر الاكتشافات الأثرية
- الفعاليات والمعارض
- أخبار المتحف

### 📸 الواقع المعزز (AR)
- عرض المجسمات بالواقع المعزز
- التعرف التلقائي على الآثار
- تجربة تفاعلية غامرة

---

## 🛠️ التقنيات المستخدمة

| التقنية | الاستخدام |
|---------|----------|
| React Native | إطار العمل الرئيسي |
| TypeScript | لغة البرمجة |
| React Navigation | التنقل بين الشاشات |
| Zustand | إدارة الحالة |
| React Native Reanimated | الأنيميشن |
| i18next | الترجمة (عربي/إنجليزي) |
| Axios | طلبات API |
| React Native Maps | الخرائط |
| React Native Video | تشغيل الفيديو |

---

## 📂 هيكل المشروع

```
giza-museum/
├── src/
│   ├── screens/           # شاشات التطبيق
│   │   ├── SplashScreen.tsx
│   │   ├── AuthScreen.tsx
│   │   ├── HomeScreen.tsx
│   │   ├── ArtifactsScreen.tsx
│   │   ├── ArtifactDetailsScreen.tsx
│   │   ├── MapScreen.tsx
│   │   ├── NewsScreen.tsx
│   │   ├── ProfileScreen.tsx
│   │   ├── AIGuideScreen.tsx
│   │   ├── FavoritesScreen.tsx
│   │   ├── QuizScreen.tsx
│   │   └── SearchScreen.tsx
│   │
│   ├── components/        # المكونات المشتركة
│   ├── navigation/        # نظام التنقل
│   ├── services/          # خدمات API
│   │   └── AIGuideService.ts
│   ├── hooks/             # React Hooks مخصصة
│   ├── utils/             # دوال مساعدة
│   ├── constants/         # الثوابت والثيم
│   │   ├── theme.ts
│   │   └── translations.ts
│   ├── types/             # أنواع TypeScript
│   └── assets/            # الصور والأيقونات
│
├── App.tsx               # المكون الرئيسي
├── index.js              # نقطة الدخول
├── package.json          # التبعيات
└── tsconfig.json         # إعدادات TypeScript
```

---

## 🚀 التثبيت والتشغيل

### المتطلبات
- Node.js 18+
- npm أو yarn
- React Native CLI
- Android Studio (للأندرويد)
- Xcode (لـ iOS)

### خطوات التثبيت

```bash
# 1. استنساخ المشروع
git clone https://github.com/your-username/giza-museum.git
cd giza-museum

# 2. تثبيت التبعيات
npm install

# 3. تثبيت pods لـ iOS
cd ios && pod install && cd ..

# 4. تشغيل التطبيق
# للأندرويد
npm run android

# لـ iOS
npm run ios
```

---

## ⚙️ إعداد الـ APIs

### المرشد الذكي (AI)
قم بتعديل ملف `src/services/AIGuideService.ts`:

```typescript
const API_CONFIG = {
  // OpenAI
  OPENAI_API_KEY: 'your-openai-api-key',
  
  // أو Google Gemini
  GEMINI_API_KEY: 'your-gemini-api-key',
  
  // أو Claude
  CLAUDE_API_KEY: 'your-claude-api-key',
};
```

---

## 🎨 الثيم والألوان

التطبيق يستخدم ثيم مستوحى من الحضارة المصرية:

| اللون | الكود | الاستخدام |
|-------|-------|----------|
| تيل/سيان | `#00BFA6` | اللون الرئيسي |
| ذهبي | `#D4AF37` | اللون الثانوي |
| أزرق داكن | `#0A1628` | الخلفية |

---

## 📱 الشاشات

| الشاشة | الوصف |
|--------|-------|
| Splash | شاشة البداية |
| Auth | تسجيل الدخول |
| Home | الصفحة الرئيسية |
| Artifacts | تصفح الآثار |
| ArtifactDetails | تفاصيل الأثر |
| Map | خريطة المتحف |
| News | الأخبار |
| Profile | الملف الشخصي |
| AIGuide | المرشد الذكي |
| Quiz | الألعاب التعليمية |

---

## 🌐 دعم اللغات

- 🇸🇦 العربية (RTL)
- 🇬🇧 English (LTR)

---

## 📄 الرخصة

هذا المشروع مرخص تحت رخصة MIT - انظر ملف [LICENSE](LICENSE) للتفاصيل.

---

## 👥 المساهمة

نرحب بمساهماتكم! يرجى قراءة [CONTRIBUTING.md](CONTRIBUTING.md) للتفاصيل.

---

## 📞 التواصل

- 📧 البريد: info@khatwatmasr.com
- 🌐 الموقع: [www.khatwatmasr.com](https://www.khatwatmasr.com)

---

<div align="center">

**صُنع بـ ❤️ في مصر 🇪🇬**

</div>
