# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Repository Layout

This repo is a monorepo with **three independent subprojects** plus shared backend SQL. The active codebases are the Flutter mobile app and the React admin dashboard.

| Path | Stack | Status |
|------|-------|--------|
| `giza_museum_app/` | **Flutter 3 / Dart ^3.10.7** + Supabase | **Primary, actively developed** (all recent commits). Its Flutter Web build is no longer deployed; the mobile app is unaffected. |
| `site/` | **Astro 7 + Tailwind 4** + Supabase (anon, read-only) | **Public website** at `5atwat-masr.vercel.app` (ar `/`, en `/en`); builds `admin-dashboard` into `/admin`. See `site/README.md`. |
| `admin-dashboard/` | **React 19 + Vite 7 + TS + Tailwind 4** + Supabase | Active — content management UI, served under `/admin` |
| `supabase/` | SQL migrations + RLS policies | Shared backend for both apps |
| `./` (root) | React Native 0.81 / Expo 54 + TypeScript | **Legacy** — earlier iteration; do not edit unless explicitly asked |
| `giza_admin_web/` | Flutter web | Empty boilerplate — ignore |

When working in this repo: identify which subproject the task targets before running commands. Each subproject has its own dependency manager (`pubspec.yaml` vs `package.json`) and its own `android/` / `ios/` build configs.

## Development Commands

### Flutter mobile app (`giza_museum_app/`)

```bash
cd giza_museum_app
flutter pub get

# Run on a connected device/emulator. Secrets MUST be injected at build time.
flutter run \
  --dart-define=SUPABASE_URL=$SUPABASE_URL \
  --dart-define=SUPABASE_ANON_KEY=$SUPABASE_ANON_KEY

flutter build apk --release --dart-define=... # same flags for release
flutter build ipa --release --dart-define=...

flutter test                                # all tests
flutter test test/widget_test.dart          # single test file
flutter analyze                             # static analysis (flutter_lints)
```

All three `AppConfig` values (`SUPABASE_URL`, `SUPABASE_ANON_KEY`) default to empty in `lib/config/app_config.dart` — without them Supabase init fails gracefully and the app runs in offline/fallback mode. There is no `GEMINI_API_KEY`: AI features go through the `ai-guide-proxy` Edge Function.

### Admin dashboard (`admin-dashboard/`)

```bash
cd admin-dashboard
npm install
npm run dev          # Vite dev server (base path: /admin/)
npm run build        # tsc -b && vite build
npm run lint         # eslint
npm run preview      # preview production build
```

Supabase credentials are read from a `.env` (Vite `import.meta.env`). The router uses `basename="/admin"` and Vite is configured with `base: '/admin/'` — links and asset paths assume the app is mounted under `/admin`.

### Supabase

SQL migrations live in `supabase/migrations/` (numbered, apply in order — 020+ enforce server-side staff permissions via `public.has_staff_role()`). Apply via Supabase CLI or SQL editor against project `xjabdikcnrczdnubozvr` (see `supabase/.temp/project-ref` / admin `.env`). Legacy one-off fix scripts live in `supabase/deprecated/` — do not run them.

## Architecture — Flutter App (`giza_museum_app/lib/`)

Entry: `main.dart` initializes `EasyLocalization` → `OfflineService` (Hive) → `Supabase` → wraps app in 4 `ChangeNotifierProvider`s, then `MaterialApp` with a single `/` route to `RootScreen`.

```
lib/
├── main.dart                # bootstrap: easy_localization + Hive + Supabase + providers
├── config/app_config.dart   # compile-time secrets via String.fromEnvironment
├── data/                    # static seed data (museum_data, facilities, itineraries)
├── localization/            # app_localizations.dart (manual strings outside easy_localization)
├── models/                  # plain Dart models: artifact, news_item, museum, governorate, map_location, media_item, game_question, itinerary, facility
├── providers/               # 4 ChangeNotifier providers (language, theme, favorites, accessibility)
├── screens/                 # one file per screen; games/ and admin/ subdirs for grouped flows
├── services/                # ai_guide_service, audio_guide_service, offline_service, secure_storage, error_handler
├── theme/app_theme.dart     # light, dark, AND highContrast themes — selected dynamically in main.dart
├── utils/input_sanitizer.dart
└── widgets/                 # shared UI: artifact_card, audio_guide_player, custom_video_player, comments_widget, etc.
```

**State management:** Provider (`ChangeNotifierProvider`). The legacy CLAUDE.md mentioned Zustand — that applied to the root RN app and is no longer relevant.

**Theme selection (non-obvious):** `main.dart` picks the active `ThemeData` in this order: `AccessibilityProvider.highContrast` → `ThemeProvider.isDarkMode` → light. Accessibility also drives `MediaQuery.textScaler` for in-app text scaling.

**Localization:** `easy_localization` with JSON files in `assets/translations/`. Supported locales: **ar, en, fr, es, de, zh, ja** (fallback `ar`). RTL is handled by Flutter automatically based on locale.

**Offline caching:** `OfflineService` opens two Hive boxes (`artifacts_cache`, `offline_settings`) at startup. `connectivityStream` (from `connectivity_plus`) drives the connectivity banner in the UI.

**Secrets:** Never hardcode. `AppConfig` reads `SUPABASE_URL`, `SUPABASE_ANON_KEY` via `String.fromEnvironment`. Use `flutter_secure_storage` (`SecureLocalStorage`) for Supabase session persistence — wired into `Supabase.initialize` in `main.dart`.

**Error handling:** `ErrorHandler` holds a global `navigatorKey` (also assigned to `MaterialApp.navigatorKey`) for navigation from non-widget contexts and provides centralized `log()`.

**AI Guide:** `ai_guide_service.dart` calls the `ai-guide-proxy` Supabase Edge Function for chat (no LLM key on-device) and falls back to a built-in static knowledge base when the proxy is unreachable or returns nothing.

## Architecture — Admin Dashboard (`admin-dashboard/src/`)

React 19 SPA mounted at `/admin`. Pages map 1:1 to Supabase tables.

- `App.tsx`: `AuthProvider` wraps `BrowserRouter basename="/admin"`. `ProtectedRoutes` redirects to `/login` if `useAuth().isAuthenticated` is false.
- `context/`: `AuthContext` (Supabase auth)
- `pages/`: Dashboard, Governorates, Museums, Artifacts, News, MapLocations, Tickets, Quizzes, Episodes, Users, Settings, Login
- `components/Layout.tsx`: shared shell (sidebar/header)
- `lib/`: Supabase client + helpers
- `services/`, `data/`: business logic and static lookups
- Tailwind CSS 4 via `@tailwindcss/vite` plugin (no separate config file)

## Conventions & Gotchas

- **Don't run `npm install` at the repo root** unless you're intentionally working on the legacy RN app. The root `package.json` predates the Flutter migration.
- **Bilingual content shape:** models carry parallel fields (e.g., `name` / `nameEn`, `description` / `descriptionEn`). When adding new content fields, follow the same pairing for Arabic + English at minimum.
- **Always pass `--dart-define` flags** when invoking Flutter — `flutter run` without them will produce a build where Supabase anon key is empty and AI features silently no-op.
- **Lint/test commands per subproject only.** There is no top-level lint or test runner that spans everything.
- **Admin dashboard is path-coupled to `/admin`.** Changing the base path requires updating both `vite.config.ts` (`base`) and `App.tsx` (`basename`) together.
- **Provider order matters in `main.dart`:** `AccessibilityProvider` is created with `..load()` so it can hydrate from disk before first build. Preserve this if reordering.
