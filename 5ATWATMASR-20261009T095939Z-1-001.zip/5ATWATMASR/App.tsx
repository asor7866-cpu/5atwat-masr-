// التطبيق الرئيسي - 5atwat Masr App

import React, { useEffect, useState } from 'react';
import { StatusBar, I18nManager, LogBox, View, ActivityIndicator } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';

// تهيئة i18n (يجب أن يكون قبل أي مكون يستخدم الترجمة)
import './src/i18n';

import AppNavigator from './src/navigation/AppNavigator';
import { Colors, getColors } from './src/constants/theme';
import { useSettingsStore } from './src/store/settingsStore';
import { useBookmarksStore } from './src/store/bookmarksStore';

// تجاهل التحذيرات غير الضرورية
LogBox.ignoreLogs([
  'ViewPropTypes will be removed',
  'ColorPropType will be removed',
]);

// تفعيل RTL للعربية
I18nManager.allowRTL(true);
I18nManager.forceRTL(true);

const App: React.FC = () => {
  const [isReady, setIsReady] = useState(false);
  const { initializeSettings, isInitialized, darkMode } = useSettingsStore();
  const { initializeBookmarks } = useBookmarksStore();

  useEffect(() => {
    // تهيئة التطبيق
    initializeApp();
  }, []);

  const initializeApp = async () => {
    try {
      // تحميل الإعدادات والمحفوظات
      await initializeSettings();
      await initializeBookmarks();
      console.log('5atwat Masr App initialized');
      setIsReady(true);
    } catch (error) {
      console.error('App initialization error:', error);
      setIsReady(true); // المتابعة حتى في حالة الخطأ
    }
  };

  // الحصول على الألوان حسب الوضع
  const themeColors = getColors(darkMode);

  // عرض شاشة تحميل أثناء تهيئة الإعدادات
  if (!isReady || !isInitialized) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: Colors.background }}>
        <ActivityIndicator size="large" color={Colors.primary} />
      </View>
    );
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <StatusBar
          barStyle={darkMode ? 'light-content' : 'dark-content'}
          backgroundColor={themeColors.background}
          translucent={false}
        />
        <AppNavigator />
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
};

export default App;
