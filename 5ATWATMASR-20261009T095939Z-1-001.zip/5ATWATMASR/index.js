// نقطة دخول التطبيق - Expo Entry Point

import { registerRootComponent } from 'expo';
import App from './App';

// registerRootComponent calls AppRegistry.registerComponent('main', ...)
// It also ensures that the native apps are correctly configured for Expo
registerRootComponent(App);
