# 🏛️ Giza Museum Project - هيكل المشروع الكامل

<div align="center">

**متحف الجيزة الرقمي - نظام متكامل (Mobile + Web + Backend)**

[![React Native](https://img.shields.io/badge/React%20Native-0.81-61dafb.svg)](https://reactnative.dev/)
[![Flutter](https://img.shields.io/badge/Flutter-3.10-02569B.svg)](https://flutter.dev/)
[![React](https://img.shields.io/badge/React-19.2-61dafb.svg)](https://react.dev/)
[![Supabase](https://img.shields.io/badge/Supabase-Backend-3ECF8E.svg)](https://supabase.com/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.3-3178C6.svg)](https://www.typescriptlang.org/)

</div>

---

## 📦 مكونات المشروع

### 1️⃣ تطبيق موبايل React Native (المشروع الرئيسي)

**المسار:** `/` (المجلد الرئيسي)

تطبيق موبايل متكامل للمستخدمين النهائيين يعمل على iOS و Android.

#### 🎯 المميزات:
- ✅ استكشاف الآثار المصرية القديمة
- ✅ مرشد ذكي بالـ AI (OpenAI/Gemini/Claude)
- ✅ خرائط تفاعلية للمتحف
- ✅ دليل صوتي بالعربية والإنجليزية
- ✅ ألعاب تعليمية وكويزات
- ✅ واقع معزز AR لعرض المجسمات
- ✅ أخبار واكتشافات أثرية
- ✅ المفضلة والملف الشخصي
- ✅ دعم كامل للغة العربية (RTL)

#### 🛠️ التقنيات:
- **Framework:** React Native 0.81.5
- **Language:** TypeScript 5.3
- **State Management:** Zustand
- **Navigation:** React Navigation v6
- **UI/Animations:** React Native Reanimated, Linear Gradient
- **i18n:** i18next (Arabic/English)
- **Backend:** Supabase
- **AI:** Google Generative AI, OpenAI API support
- **Maps:** React Native Maps
- **AR:** Expo Camera, Expo GL
- **3D:** Three.js + React Three Fiber

#### 📂 الهيكل:
```
/
├── src/
│   ├── screens/          # جميع شاشات التطبيق
│   ├── components/       # المكونات القابلة لإعادة الاستخدام
│   ├── navigation/       # إعدادات React Navigation
│   ├── services/         # API وخدمات خارجية
│   ├── store/           # Zustand state management
│   ├── hooks/           # Custom React Hooks
│   ├── constants/       # Theme, Colors, Translations
│   ├── types/           # TypeScript types
│   ├── utils/           # Utility functions
│   └── assets/          # Images, Icons, Fonts
├── android/             # Android native code
├── App.tsx              # App entry point
└── package.json
```

#### 🚀 التشغيل:
```bash
# تثبيت التبعيات
npm install

# iOS pods
cd ios && pod install && cd ..

# تشغيل Android
npm run android

# تشغيل iOS
npm run ios
```

---

### 2️⃣ تطبيق موبايل Flutter (نسخة بديلة)

**المسار:** `/giza_museum_app`

نسخة بديلة من التطبيق مكتوبة بـ Flutter/Dart (في مرحلة التطوير).

#### 🛠️ التقنيات:
- **Framework:** Flutter 3.10+
- **Language:** Dart
- **SDK:** ^3.10.7

#### 📂 الهيكل:
```
giza_museum_app/
├── lib/
│   ├── main.dart
│   ├── screens/         # UI Screens
│   ├── widgets/         # Reusable widgets
│   ├── models/          # Data models
│   ├── data/           # Data layer
│   └── theme/          # App theme
├── assets/
└── pubspec.yaml
```

#### 🚀 التشغيل:
```bash
cd giza_museum_app

# تثبيت التبعيات
flutter pub get

# تشغيل التطبيق
flutter run
```

---

### 3️⃣ لوحة التحكم الإدارية (Web Dashboard)

**المسار:** `/admin-dashboard`

تطبيق ويب لإدارة محتوى المتحف من قبل المسؤولين.

#### 🎯 المميزات:
- ✅ إدارة الآثار (إضافة/تعديل/حذف)
- ✅ إدارة الأخبار والمقالات
- ✅ إدارة المستخدمين
- ✅ إدارة الكويزات والأسئلة
- ✅ رفع الصور والملفات
- ✅ إحصائيات ولوحة معلومات
- ✅ واجهة حديثة ومتجاوبة

#### 🛠️ التقنيات:
- **Framework:** React 19.2
- **Build Tool:** Vite 7.2
- **Language:** TypeScript 5.9
- **Styling:** Tailwind CSS 4.1
- **UI Components:** Lucide Icons, Framer Motion
- **Forms:** React Hook Form
- **Routing:** React Router DOM v7
- **State:** Zustand
- **Backend:** Supabase

#### 📂 الهيكل:
```
admin-dashboard/
├── src/
│   ├── components/      # UI Components
│   ├── pages/          # Dashboard pages
│   ├── hooks/          # Custom hooks
│   ├── utils/          # Utilities
│   └── styles/         # Tailwind config
├── public/
├── index.html
├── vite.config.ts
└── package.json
```

#### 🚀 التشغيل:
```bash
cd admin-dashboard

# تثبيت التبعيات
npm install

# تشغيل Development Server
npm run dev

# Build للإنتاج
npm run build
```

#### 🌐 الوصول:
```
Development: http://localhost:5173
```

---

### 4️⃣ Backend (Supabase)

**المسار:** `/supabase`

قاعدة بيانات PostgreSQL مع خدمات Authentication, Storage, Realtime.

#### 🎯 الخدمات:
- ✅ **Database:** PostgreSQL مع جداول الآثار، المستخدمين، الكويزات
- ✅ **Authentication:** تسجيل دخول Google، Email/Password
- ✅ **Storage:** تخزين الصور والملفات
- ✅ **Realtime:** تحديثات فورية
- ✅ **Row Level Security:** أمان على مستوى الصفوف

#### 📂 الهيكل:
```
supabase/
├── migrations/          # Database migrations
├── README.md           # Setup guide
└── storage-buckets.sql # Storage configuration
```

#### 🚀 الإعداد:
راجع ملف [SUPABASE_SETUP.md](./SUPABASE_SETUP.md) للتفاصيل الكاملة.

---

## 🏗️ معمارية المشروع (Architecture)

```
┌─────────────────────────────────────────────────────────┐
│                     Mobile Apps                          │
│  ┌──────────────────┐      ┌──────────────────┐        │
│  │  React Native    │      │     Flutter      │        │
│  │  iOS + Android   │      │  iOS + Android   │        │
│  └────────┬─────────┘      └────────┬─────────┘        │
│           │                         │                   │
└───────────┼─────────────────────────┼───────────────────┘
            │                         │
            ▼                         ▼
    ┌───────────────────────────────────────┐
    │        Supabase Backend               │
    │  ┌──────────┐  ┌──────────┐          │
    │  │ Database │  │  Storage │          │
    │  └──────────┘  └──────────┘          │
    │  ┌──────────┐  ┌──────────┐          │
    │  │   Auth   │  │ Realtime │          │
    │  └──────────┘  └──────────┘          │
    └───────────▲───────────────────────────┘
                │
                │
    ┌───────────┴───────────────────────────┐
    │       Web Admin Dashboard              │
    │      React + Vite + Tailwind          │
    └───────────────────────────────────────┘
```

---

## 📊 مقارنة المكونات

| المكون | النوع | المستخدم | التقنية الرئيسية | الحالة |
|--------|------|---------|------------------|--------|
| React Native App | Mobile | المستخدمين | React Native + TypeScript | ✅ نشط ومكتمل |
| Flutter App | Mobile | المستخدمين | Flutter + Dart | 🚧 قيد التطوير |
| Admin Dashboard | Web | المسؤولين | React + Vite | ✅ نشط ومكتمل |
| Supabase Backend | Backend | الجميع | PostgreSQL | ✅ نشط |

---

## 🔄 سير العمل (Workflow)

### للمستخدمين النهائيين:
1. تحميل التطبيق (React Native أو Flutter)
2. التسجيل/تسجيل الدخول
3. استكشاف الآثار، استخدام AI Guide، لعب الكويزات

### للمسؤولين:
1. الدخول إلى Admin Dashboard (Web)
2. إدارة المحتوى (آثار، أخبار، كويزات)
3. التحديثات تظهر فوراً في تطبيقات الموبايل

---

## 🔧 متطلبات التطوير

### للتطبيقات:

#### React Native:
- Node.js 18+
- React Native CLI
- Android Studio (Android)
- Xcode (iOS - macOS only)

#### Flutter:
- Flutter SDK 3.10+
- Dart SDK 3.10+
- Android Studio / Xcode

#### Admin Dashboard:
- Node.js 18+
- Modern browser

### للـ Backend:
- حساب Supabase (مجاني للتطوير)
- API Keys للخدمات الخارجية (Google AI, etc.)

---

## 🚀 البدء السريع (Quick Start)

### 1. استنساخ المشروع
```bash
git clone <repository-url>
cd giza-museum
```

### 2. إعداد Supabase
```bash
# راجع SUPABASE_SETUP.md للتفاصيل
```

### 3. تشغيل React Native App
```bash
npm install
npm run android  # أو npm run ios
```

### 4. تشغيل Admin Dashboard
```bash
cd admin-dashboard
npm install
npm run dev
```

### 5. (اختياري) تشغيل Flutter App
```bash
cd giza_museum_app
flutter pub get
flutter run
```

---

## 📝 ملاحظات مهمة

### ⚠️ API Keys مطلوبة:
- **Supabase:** URL + Anon Key
- **Google AI (Gemini):** API Key للمرشد الذكي
- **Google Maps:** API Key للخرائط (Android/iOS)

### 🔐 ملفات البيئة:

#### React Native (`.env`):
```env
SUPABASE_URL=your_supabase_url
SUPABASE_ANON_KEY=your_anon_key
GEMINI_API_KEY=your_gemini_key
GOOGLE_MAPS_API_KEY=your_maps_key
```

#### Admin Dashboard (`.env`):
```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_anon_key
```

---

## 📚 ملفات التوثيق الإضافية

- [CLAUDE.md](./CLAUDE.md) - تعليمات للتطوير بـ Claude Code
- [SUPABASE_SETUP.md](./SUPABASE_SETUP.md) - دليل إعداد Supabase
- [APPLY_MIGRATIONS.md](./APPLY_MIGRATIONS.md) - تطبيق Database Migrations
- [admin-dashboard/README.md](./admin-dashboard/README.md) - تفاصيل لوحة التحكم

---

## 🎨 Design System

### الألوان:
- **Primary:** `#00BFA6` (Teal/Cyan - مستوحى من النيل)
- **Secondary:** `#D4AF37` (Gold - الذهب المصري)
- **Background:** `#0A1628` (Dark Blue - ليل الصحراء)

### الخطوط:
- **Arabic:** Cairo
- **English:** Poppins

---

## 🤝 المساهمة

نرحب بالمساهمات! يرجى:
1. Fork المشروع
2. إنشاء branch للميزة الجديدة
3. Commit التغييرات
4. Push وإنشاء Pull Request

---

## 📄 الترخيص

MIT License - راجع [LICENSE](./LICENSE)

---

## 📞 الدعم والتواصل

- 📧 Email: info@gizamuseum.com
- 🐛 Issues: GitHub Issues
- 📖 Docs: `/docs`

---

<div align="center">

**🏛️ صُنع بـ ❤️ لحفظ التراث المصري العريق 🇪🇬**

</div>
