# 🚀 دليل التكامل الكامل مع Supabase

## ✅ ما تم إنجازه

تم بنجاح إعداد البنية التحتية الكاملة لـ Supabase:

### 1. قاعدة البيانات
- ✅ 16 جدول رئيسي
- ✅ Row Level Security (RLS) على جميع الجداول
- ✅ Indexes لتحسين الأداء
- ✅ Triggers تلقائية
- ✅ دوال مخصصة (Functions)

### 2. المصادقة (Authentication)
- ✅ Email/Password Auth
- ✅ Google OAuth
- ✅ Session Management
- ✅ Auth Store بـ Zustand
- ✅ تكامل كامل مع AuthScreen

### 3. التخزين (Storage)
- ✅ 6 Storage Buckets
- ✅ Storage Policies
- ✅ دعم الصور والملفات الكبيرة

### 4. الخدمات (Services)
- ✅ SupabaseService شامل
- ✅ دوال للآثار، المفضلات، الاختبارات
- ✅ دعم Realtime Subscriptions
- ✅ Upload/Download للملفات

## 📋 الخطوات التالية

### الخطوة 1: تشغيل Migrations

اذهب إلى Supabase Dashboard > SQL Editor وشغّل:

1. `supabase/migrations/001_create_tables.sql`
2. `supabase/migrations/002_row_level_security.sql`
3. `supabase/migrations/003_storage_buckets.sql`

**أو** استخدم Supabase CLI:

```bash
cd /Users/islamtaha/Downloads/giza-museum
supabase db push
```

### الخطوة 2: تهيئة Auth في App.tsx

أضف التهيئة في `App.tsx`:

```typescript
import { useAuthStore } from './src/store/authStore';

function App() {
  const { initialize } = useAuthStore();

  useEffect(() => {
    // تهيئة المصادقة
    initialize();
  }, []);

  // باقي الكود...
}
```

### الخطوة 3: حماية الشاشات

أضف حماية للشاشات التي تحتاج مصادقة:

```typescript
// في AppNavigator.tsx
import { useAuthStore } from '@/store/authStore';

function AppNavigator() {
  const { user, initialized } = useAuthStore();

  if (!initialized) {
    return <SplashScreen />;
  }

  return (
    <NavigationContainer>
      <RootStack.Navigator>
        {!user ? (
          <RootStack.Screen name="Auth" component={AuthScreen} />
        ) : (
          <>
            <RootStack.Screen name="Main" component={MainTabNavigator} />
            {/* باقي الشاشات */}
          </>
        )}
      </RootStack.Navigator>
    </NavigationContainer>
  );
}
```

### الخطوة 4: تحديث الشاشات لاستخدام Supabase

#### مثال: ArtifactsScreen

```typescript
import { useState, useEffect } from 'react';
import SupabaseService from '@/services/SupabaseService';

function ArtifactsScreen() {
  const [artifacts, setArtifacts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadArtifacts();
  }, []);

  const loadArtifacts = async () => {
    try {
      const data = await SupabaseService.getArtifacts({
        limit: 20,
        featured: true
      });
      setArtifacts(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  // باقي الكود...
}
```

#### مثال: FavoritesScreen

```typescript
import { useAuthStore } from '@/store/authStore';
import SupabaseService from '@/services/SupabaseService';

function FavoritesScreen() {
  const { user } = useAuthStore();
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    if (user) {
      loadFavorites();
    }
  }, [user]);

  const loadFavorites = async () => {
    try {
      const data = await SupabaseService.getFavorites(user.id);
      setFavorites(data);
    } catch (error) {
      console.error(error);
    }
  };

  const toggleFavorite = async (artifactId: string) => {
    try {
      const isFav = await SupabaseService.isFavorite(user.id, artifactId);

      if (isFav) {
        await SupabaseService.removeFavorite(user.id, artifactId);
      } else {
        await SupabaseService.addFavorite(user.id, artifactId);
      }

      // إعادة تحميل المفضلات
      loadFavorites();
    } catch (error) {
      console.error(error);
    }
  };

  // باقي الكود...
}
```

### الخطوة 5: إضافة بيانات تجريبية

يمكنك إضافة بيانات تجريبية من SQL Editor:

```sql
-- إضافة موقع تجريبي
INSERT INTO public.locations (name, name_en, city, coordinates)
VALUES (
  'الأقصر',
  'Luxor',
  'الأقصر',
  POINT(25.6872, 32.6396)
);

-- إضافة أثر تجريبي
INSERT INTO public.artifacts (
  name,
  name_en,
  description,
  description_en,
  era,
  category,
  current_location,
  is_featured
) VALUES (
  'قناع توت عنخ آمون',
  'Tutankhamun Mask',
  'القناع الذهبي الشهير للملك توت عنخ آمون',
  'The famous golden mask of King Tutankhamun',
  'new_kingdom',
  'jewelry',
  'المتحف المصري الكبير',
  true
);

-- إضافة خبر تجريبي
INSERT INTO public.news (
  title,
  title_en,
  content,
  content_en,
  summary,
  summary_en,
  image_url,
  category,
  author
) VALUES (
  'افتتاح معرض جديد',
  'New Exhibition Opening',
  'افتتاح معرض جديد للآثار الفرعونية...',
  'Opening of a new Pharaonic artifacts exhibition...',
  'معرض جديد يضم 50 قطعة أثرية',
  'New exhibition featuring 50 artifacts',
  'https://example.com/image.jpg',
  'exhibition',
  'فريق المتحف'
);
```

## 🔧 تكامل متقدم

### Realtime Updates

لتفعيل التحديثات الفورية للأخبار:

```typescript
useEffect(() => {
  const subscription = SupabaseService.subscribeToTable(
    'news',
    (payload) => {
      if (payload.eventType === 'INSERT') {
        // خبر جديد
        setNews(prev => [payload.new, ...prev]);
      }
    }
  );

  return () => {
    SupabaseService.unsubscribe(subscription);
  };
}, []);
```

### Image Upload

لرفع صور Avatar:

```typescript
import { launchImageLibrary } from 'react-native-image-picker';

const uploadAvatar = async () => {
  const result = await launchImageLibrary({ mediaType: 'photo' });

  if (result.assets && result.assets[0]) {
    const file = {
      uri: result.assets[0].uri,
      name: `${user.id}_avatar.jpg`,
      type: 'image/jpeg'
    };

    try {
      await SupabaseService.uploadImage(
        'avatars',
        `${user.id}/avatar.jpg`,
        file
      );

      const avatarUrl = SupabaseService.getPublicUrl(
        'avatars',
        `${user.id}/avatar.jpg`
      );

      // تحديث ملف المستخدم
      await SupabaseService.updateUserProfile(user.id, {
        avatar_url: avatarUrl
      });
    } catch (error) {
      console.error(error);
    }
  }
};
```

### Offline Support

لإضافة دعم Offline، يمكن دمج AsyncStorage:

```typescript
// في SupabaseService.ts
async getArtifacts() {
  try {
    // محاولة جلب من الإنترنت
    const data = await supabase.from('artifacts').select('*');

    // حفظ في Cache
    await AsyncStorage.setItem('artifacts', JSON.stringify(data));

    return data;
  } catch (error) {
    // في حالة عدم وجود إنترنت، جلب من Cache
    const cached = await AsyncStorage.getItem('artifacts');
    return cached ? JSON.parse(cached) : [];
  }
}
```

## 📝 ملاحظات مهمة

### الأمان

1. **لا تضع المفاتيح في Git**: أضف `src/config/supabase.ts` في `.gitignore` إذا كانت تحتوي مفاتيح حساسة
2. **استخدم Environment Variables**: انقل المفاتيح إلى `.env`

```typescript
// src/config/supabase.ts
import Config from 'react-native-config';

const SUPABASE_URL = Config.SUPABASE_URL;
const SUPABASE_KEY = Config.SUPABASE_KEY;
```

### الأداء

1. **Pagination**: استخدم دائماً pagination للقوائم الطويلة
2. **Caching**: احفظ البيانات المحملة في state
3. **Lazy Loading**: حمّل الصور بشكل lazy

### الاختبار

لاختبار التكامل:

1. تسجيل حساب جديد
2. تسجيل الدخول
3. إضافة/إزالة مفضلات
4. حل اختبار
5. عرض التقدم

## 🐛 استكشاف الأخطاء الشائعة

### خطأ: "Invalid API Key"

**الحل**: تأكد من صحة `SUPABASE_PUBLISHABLE_KEY` في `src/config/supabase.ts`

### خطأ: "User not authenticated"

**الحل**: تأكد من تسجيل الدخول قبل الوصول للبيانات المحمية

### خطأ: "Network request failed"

**الحل**: تأكد من الاتصال بالإنترنت وتفعيل Supabase APIs

## 📚 موارد إضافية

- [Supabase Documentation](https://supabase.com/docs)
- [React Native Supabase Guide](https://supabase.com/docs/guides/getting-started/tutorials/with-react-native)
- [Supabase Auth Deep Dive](https://supabase.com/docs/guides/auth)

## ✨ الخلاصة

تم إعداد تكامل كامل مع Supabase يشمل:

- ✅ قاعدة بيانات PostgreSQL كاملة
- ✅ مصادقة آمنة مع RLS
- ✅ تخزين ملفات
- ✅ Realtime subscriptions
- ✅ خدمات جاهزة للاستخدام

**الخطوة التالية**: شغّل Migrations وابدأ باستخدام الخدمات!

---

**تم الإنجاز بنجاح! 🎉**

للأسئلة أو الدعم، راجع التوثيق في `supabase/README.md`
