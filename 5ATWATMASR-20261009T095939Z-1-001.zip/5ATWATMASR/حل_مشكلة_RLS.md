# 🔧 حل مشكلة Row Level Security في Admin Dashboard

## ❌ المشكلة:
```
new row violates row-level security policy
```

### 📝 الشرح:
عند محاولة إضافة بيانات جديدة (آثار، أخبار، كويزات) من Admin Dashboard، Supabase يرفض العملية لأن:
- ✅ RLS Policies تسمح بالقراءة (SELECT) للجميع
- ❌ لا توجد Policies للإضافة/التعديل/الحذف (INSERT/UPDATE/DELETE)

---

## ✅ الحل (خطوة بخطوة):

### الطريقة 1️⃣: حل سريع للتطوير (مؤقت)

هذا الحل يسمح لأي مستخدم مسجل دخول بالإضافة والتعديل. **مناسب للتطوير فقط!**

#### الخطوات:

1. **افتح Supabase Dashboard**
   - اذهب إلى: https://supabase.com/dashboard

2. **اختر مشروعك**

3. **افتح SQL Editor**
   - من القائمة الجانبية: `SQL Editor` → `New query`

4. **الصق هذا الكود**:

```sql
-- حل سريع للتطوير - يسمح لأي مستخدم بالتعديل

-- Artifacts
CREATE POLICY "Allow authenticated users to modify artifacts"
    ON public.artifacts FOR ALL
    USING (auth.uid() IS NOT NULL)
    WITH CHECK (auth.uid() IS NOT NULL);

-- News
CREATE POLICY "Allow authenticated users to modify news"
    ON public.news FOR ALL
    USING (auth.uid() IS NOT NULL)
    WITH CHECK (auth.uid() IS NOT NULL);

-- Quizzes
CREATE POLICY "Allow authenticated users to modify quizzes"
    ON public.quizzes FOR ALL
    USING (auth.uid() IS NOT NULL)
    WITH CHECK (auth.uid() IS NOT NULL);

-- Quiz Questions
CREATE POLICY "Allow authenticated users to modify quiz questions"
    ON public.quiz_questions FOR ALL
    USING (auth.uid() IS NOT NULL)
    WITH CHECK (auth.uid() IS NOT NULL);

-- Locations
CREATE POLICY "Allow authenticated users to modify locations"
    ON public.locations FOR ALL
    USING (auth.uid() IS NOT NULL)
    WITH CHECK (auth.uid() IS NOT NULL);

-- Audio Guides
CREATE POLICY "Allow authenticated users to modify audio guides"
    ON public.audio_guides FOR ALL
    USING (auth.uid() IS NOT NULL)
    WITH CHECK (auth.uid() IS NOT NULL);
```

5. **اضغط Run** (أو Ctrl+Enter)

6. **جرب الإضافة الآن من Admin Dashboard**

---

### الطريقة 2️⃣: حل احترافي (للإنتاج) ⭐

هذا الحل يسمح فقط للمسؤولين (Admins) بالإضافة والتعديل. **آمن وموصى به!**

#### الخطوات:

**الخطوة 1: تطبيق Admin Policies**

1. افتح ملف: [`/supabase/migrations/004_admin_policies.sql`](./supabase/migrations/004_admin_policies.sql)

2. افتح Supabase Dashboard → SQL Editor

3. انسخ محتوى القسم الأول من الملف (من السطر 1 إلى السطر 195)

4. الصق في SQL Editor واضغط Run

**الخطوة 2: إنشاء مستخدم Admin**

بعد تشغيل الـ SQL:

1. سجل دخول في Admin Dashboard على `http://localhost:5173`
   - استخدم أي email وpassword للتسجيل

2. ارجع إلى Supabase Dashboard

3. اذهب إلى: `Table Editor` → `users`

4. ابحث عن المستخدم الذي سجلته للتو (بواسطة email)

5. اضغط على صف المستخدم لتعديله

6. **غيّر حقل `role` من `visitor` إلى `admin`**

7. احفظ التغييرات

**الخطوة 3: جرب الآن**

- سجل دخول مرة أخرى في Admin Dashboard
- حاول إضافة أثر أو خبر جديد
- يجب أن تنجح العملية الآن! ✅

---

## 🔍 كيف تتحقق من نجاح الإعداد؟

### التحقق من Policies:

في Supabase Dashboard → SQL Editor، شغّل:

```sql
-- عرض جميع Policies للجدول artifacts
SELECT * FROM pg_policies WHERE tablename = 'artifacts';
```

يجب أن ترى policies مثل:
- `Admins can insert artifacts`
- `Admins can update artifacts`
- `Admins can delete artifacts`

### التحقق من دور المستخدم:

```sql
-- عرض جميع المستخدمين ودورهم
SELECT id, name, email, role FROM public.users;
```

تأكد من أن المستخدم الخاص بك لديه `role = 'admin'`

---

## 🎯 الفرق بين الطريقتين:

| المعيار | الطريقة 1 (تطوير) | الطريقة 2 (إنتاج) |
|---------|-------------------|-------------------|
| **الأمان** | ⚠️ منخفض | ✅ عالي |
| **السماحية** | أي مستخدم مسجل | Admin فقط |
| **الاستخدام** | للتطوير المحلي | للإنتاج |
| **السرعة** | سريع جداً | يحتاج خطوة إضافية |

---

## 🆘 المشاكل الشائعة

### المشكلة: لا يزال الخطأ يظهر بعد تطبيق الحل

**الأسباب المحتملة:**

1. **لم تسجل دخول**
   - تأكد من تسجيل الدخول في Admin Dashboard
   - تحقق من وجود token في localStorage

2. **دور المستخدم خاطئ (الطريقة 2)**
   - تأكد من أن `role = 'admin'` في جدول `users`
   - تحقق من email المستخدم الصحيح

3. **Policies لم يتم تطبيقها**
   - راجع SQL Editor للتأكد من عدم وجود أخطاء
   - جرب تشغيل الكود مرة أخرى

4. **Session قديم**
   - سجل خروج وسجل دخول مرة أخرى
   - أو امسح Cookies وLocal Storage

### المشكلة: الآن يمكنني الإضافة ولكن لا يمكنني التعديل

**الحل:**
تأكد من وجود Policies للـ UPDATE أيضاً:

```sql
-- تحقق من policies للتعديل
SELECT * FROM pg_policies
WHERE tablename = 'artifacts'
AND cmd = 'UPDATE';
```

إذا لم تظهر نتائج، شغّل الـ SQL من ملف `004_admin_policies.sql` مرة أخرى.

---

## 📚 موارد إضافية

- [Supabase RLS Documentation](https://supabase.com/docs/guides/auth/row-level-security)
- [ملف Admin Policies](./supabase/migrations/004_admin_policies.sql)
- [دليل إعداد Supabase](./SUPABASE_SETUP.md)

---

## ✅ الخلاصة

### للتطوير السريع:
استخدم **الطريقة 1** - مجرد نسخ ولصق SQL بسيط

### للإنتاج:
استخدم **الطريقة 2** - أكثر أماناً ويسمح فقط للـ Admins

### بعد الحل:
- ✅ يمكنك إضافة آثار، أخبار، كويزات
- ✅ يمكنك التعديل والحذف
- ✅ RLS محمية ولا يمكن للمستخدمين العاديين التلاعب بالبيانات

---

<div align="center">

**تم الحل! 🎉**

الآن يمكنك استخدام Admin Dashboard بدون مشاكل

</div>
